<?php
/**
 * 
 * XML to Array Exception
 *
 */
class XmlToArrayException extends Exception {}
?>